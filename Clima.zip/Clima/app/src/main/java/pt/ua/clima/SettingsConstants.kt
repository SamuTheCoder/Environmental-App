package pt.ua.clima

class SettingsConstants {
    companion object{
        var isCelsius = true;
        var isPascal = true;
        var shareS = false;
    }
}